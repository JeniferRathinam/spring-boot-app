package com.product.review;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductReviewServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
